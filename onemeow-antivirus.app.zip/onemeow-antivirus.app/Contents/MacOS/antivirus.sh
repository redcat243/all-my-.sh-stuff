#!/bin/zsh

# --- Configuration ---
MB_API_KEY="7ef536376af2960cdcda79bbd220da0051f7e05c5fc71572" # Paste your MalwareBazaar API Key here
APP_NAME="onemeow antivirus"
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
DB_FILE="$BASE_DIR/database.txt"
KEY_FILE="$BASE_DIR/registration-keys.txt"
STATE_FILE="$BASE_DIR/.onemeow_state"
TRIAL_DAYS=30
# Define the file path where the status will be saved
STATUS_FILE1="$HOME/.setup_status"

# 1. READ THE STATUS (Defaults to 0 if the file doesn't exist)
if [[ -f "$STATUS_FILE1" ]]; then
    setupcomplete=$(cat "$STATUS_FILE1")
else
    setupcomplete=0
fi

# 2. CHECK THE STATUS
if (( setupcomplete == 0 )); then
    echo "Running setup for the first time..."
    
    touch "$STATE_FILE"
    
    # 3. SAVE THE STATUS TO THE FILE
    touch "$STATE_FILE1"
    echo "1" > "$STATUS_FILE1"
    echo "Setup complete! Status saved."
else
    echo "Setup already completed in a previous run. Skipping."
fi
#antivirus starts
# Ensure database exists so 'wc' doesn't fail
touch "$DB_FILE"
touch "$BASE_DIR"

# --- 1. Boot Sequence ---
show_loading_bar() {
    local duration=60
    clear
    echo -e "\033[1;36m[BOOT]\033[0m Initializing $APP_NAME..."
    for ((i=0; i<=duration; i++)); do
        local percent=$(( i * 100 / duration ))
        printf "\r\033[1;32m[%-40s]\033[0m %d%%" "$(printf '█%.0s' {1..$((i*40/duration))})" "$percent"
        [[ $i -lt $duration ]] && sleep 1
    done
    echo -e "\n\n\033[1;35m[SUCCESS]\033[0m jello inject loaded\n"
}

# --- 2. GUI Helpers ---
gui_msg() {
    osascript -e "tell application \"Finder\" to display dialog \"$1\" buttons {\"OK\"} default button 1 with title \"$APP_NAME\"" >/dev/null 2>&1
}

gui_alert() {
    osascript -e "tell application \"Finder\" to display alert \"$APP_NAME\" message \"$1\" as critical" >/dev/null 2>&1
}

# --- 3. Features ---

fetch_updates() {
    if [[ -z "$MB_API_KEY" ]]; then
        gui_alert "No API Key found. Please add your MalwareBazaar key to the script."
        return
    fi
    osascript -e "display notification \"Fetching latest hashes...\" with title \"$APP_NAME\""
    
    local response=$(curl -sS -H "Auth-Key: $MB_API_KEY" --data "query=get_recent&selector=100" "https://mb-api.abuse.ch/api/v1/" 2>/dev/null)
    local result=$(echo "$response" | python3 -c "import json,sys; d=json.load(sys.stdin); [print(i['sha256_hash']) for i in d['data']] if d['query_status']=='ok' else None" 2>/dev/null)

    if [[ -n "$result" ]]; then
        echo "$result" >> "$DB_FILE"
        gui_msg "Signatures updated! Total: $(wc -l < "$DB_FILE" | xargs)"
    else
        gui_alert "Update failed. Check your network or API key."
    fi
}

scan_path() {
    local target="$1"
    osascript -e "display notification \"Scanning $target...\" with title \"$APP_NAME\""
    echo "[SCAN] Processing $target..."
    local found=0
    find "$target" -type f 2>/dev/null | while read -r file; do
        local filehash=$(shasum -a 256 "$file" | awk '{print $1}')
        if grep -Fq "$filehash" "$DB_FILE" 2>/dev/null; then
            gui_alert "THREAT DETECTED: $(basename "$file")"
            found=1
        fi
    done
    [[ $found -eq 0 ]] && gui_msg "Scan complete. No threats found in $target."
}

do_activation() {
    local input=$(osascript <<EOF
    tell application "Finder"
        activate
        set theResponse to display dialog "Enter Activation Key:" default answer "" with title "$APP_NAME"
        return text returned of theResponse
    end tell
EOF
)
    if [[ -n "$input" ]]; then
        local clean_input=$(echo "$input" | tr -d '[:space:]' | tr '[:lower:]' '[:upper:]')
        if grep -i -q "^$clean_input$" "$KEY_FILE" 2>/dev/null; then
            activated=true
            echo "install_date=$install_date\nactivated=true" > "$STATE_FILE"
            gui_msg "Activation Successful! Full Version Unlocked."
        else
            gui_alert "Invalid Key. Please check registration-keys.txt"
        fi
    fi
}

# --- 4. Main Menu ---
main_menu() {
    while true; do
        local choice=$(osascript <<EOF
        tell application "Finder"
            activate
            choose from list {"Full Scan", "Custom Scan", "Update Signatures", "Status", "Activate", "Exit"} with title "$APP_NAME"
        end tell
EOF
)
        case "$choice" in
            "Full Scan")
                local now=$(date +%s); local diff=$(( (now - install_date) / 86400 ))
                if [[ "$activated" == "false" && $diff -ge $TRIAL_DAYS ]]; then
                    gui_alert "Trial Expired. Please activate."
                else
                    scan_path "$HOME"
                fi ;;
            "Custom Scan")
                if [[ "$activated" == "false" && $(( ($(date +%s) - install_date) / 86400 )) -ge $TRIAL_DAYS ]]; then
                    gui_alert "Trial Expired. Please activate."
                else
                    local folder=$(osascript -e "tell application \"Finder\" to POSIX path of (choose folder with prompt \"Select folder to scan\")" 2>/dev/null)
                    [[ -n "$folder" ]] && scan_path "$folder"
                fi ;;
            "Update Signatures") fetch_updates ;;
            "Status")
                local now=$(date +%s); local diff=$(( (now - install_date) / 86400 ))
                [[ "$activated" == "true" ]] && m="Activated" || m="Trial Day $diff / $TRIAL_DAYS"
                gui_msg "Unix Core: 12.7.6\nStatus: $m\nSignatures: $(wc -l < "$DB_FILE" | xargs)" ;;
            "Activate") do_activation ;;
            "Exit"|false) exit 0 ;;
        esac
    done
}

# --- Execution ---
show_loading_bar
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || { install_date=$(date +%s); activated=false; }
main_menu
fi